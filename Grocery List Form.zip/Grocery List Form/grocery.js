document.getElementById('grocery-form').addEventListener('submit', function (event) { 
    event.preventDefault();

    const name = document.getElementById('name').value;    
    const category = document.getElementById('category').value;    
    let quantity = parseFloat(document.getElementById('quantity').value);    
    const price = parseFloat(document.getElementById('price').value);
    
    let quantityUnit = '';    
    if (category === 'Fruits' || category === 'Vegetables') {    
        quantityUnit = 'kg';    
    } else if (category === 'Dairy') {    
        quantityUnit = 'liters';    
    } else if (category === 'Bakery') {    
        quantityUnit = 'qty';
    }
    
    const listItem = document.createElement('li');    
    listItem.textContent = `${name} (${category}) - ${quantity} ${quantityUnit} x ${price.toFixed(2)}Rs = ${(quantity * price).toFixed(2)}Rs`;
    
    document.getElementById('grocery-list').appendChild(listItem);
    
    updateTotalPrice (quantity * price);
    
    document.getElementById('grocery-form').reset();
    
    });

    function updateTotalPrice(itemTotalPrice) {    
    const totalPriceElement = document.getElementById('total-price');
    const currentTotal = parseFloat(totalPriceElement.textContent);    
    const newTotal = currentTotal + itemTotalPrice;    
    totalPriceElement.textContent = newTotal.toFixed(2) + 'Rs';
}